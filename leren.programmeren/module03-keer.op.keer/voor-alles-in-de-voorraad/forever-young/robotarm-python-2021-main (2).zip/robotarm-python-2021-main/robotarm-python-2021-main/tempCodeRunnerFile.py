robotArm.moveRight()
